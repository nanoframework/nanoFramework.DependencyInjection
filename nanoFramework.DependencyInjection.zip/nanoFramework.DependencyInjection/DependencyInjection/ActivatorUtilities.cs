﻿// Licensed to the .NET Foundation under one or more agreements.
// The .NET Foundation licenses this file to you under the MIT license.

using System;
using System.Reflection;

namespace nanoFramework.DependencyInjection
{
    /// <summary>
    /// Helper code for the various activator services.
    /// </summary>
    public static class ActivatorUtilities
    {
        /// <summary>
        /// Create a delegate that will instantiate a type with constructor arguments provided directly and/or from an <see cref="IServiceProvider"/>.
        /// </summary>
        /// <param name="instanceType">The type to activate.</param>
        /// <param name="argumentTypes">The types of objects, in order, that will be passed to the returned function as its second parameter.</param>
        /// <returns><see cref="ObjectFactory"/></returns>
        public static ObjectFactory CreateFactory(Type instanceType, Type[] argumentTypes)
        {
            if (instanceType == null)
            {
                throw new ArgumentNullException(nameof(instanceType));
            }

            int i = 0;
            ConstructorInfo[] constructors = new ConstructorInfo[10]; //TODO: Fix
            foreach (ConstructorInfo constructor in instanceType.GetConstructors())
            {
                if (IsInjectable(constructor))
                {
                    constructors[i] = constructor;
                    i++;
                }
            }

            if (constructors.Length == 1)
            {
                ParameterInfo[] parameters = constructors[0].GetParameters();
                return services =>
                {
                    var args = new object[parameters.Length];
                    for (int index = 0; index != parameters.Length; ++index)
                    {
                        args[index] = services.GetService(parameters[index].ParameterType);
                    }
                    return Activator.CreateInstance(instanceType, args);
                };
            }

            return _ => Activator.CreateInstance(instanceType);
        }

        /// <summary>
        /// Instantiate a type with constructor arguments provided directly and/or from an IServiceProvider.
        /// </summary>
        /// <param name="provider">The service provider used to resolve dependencies.</param>
        /// <param name="instanceType">The type to activate.</param>
        /// <param name="parameters">Constructor arguments not provided by the provider.</param>
        /// <returns>The activated object.</returns>
        public static object CreateInstance(IServiceProvider provider, Type instanceType, params object[] parameters)
        {
            //return CreateFactory(instanceType, parameters).Invoke(provider);
            return null;
        }

        /// <summary>
        /// Retrieve an instance of the given type from the service provider. If one is not found then instantiate it directly.
        /// </summary>
        /// <param name="provider">The service provider.</param>
        /// <param name="type">The type of the service.</param>
        /// <returns>The resolved service or created instance.</returns>
        public static object GetServiceOrCreateInstance(IServiceProvider provider, Type type)
        {
            return GetServiceNoExceptions(provider, type) ?? Activator.CreateInstance(type);
        }

        private static bool IsInjectable(ConstructorInfo constructor)
        {
            return constructor.IsPublic && constructor.GetParameters().Length != 0;
        }
        
        private static object GetServiceNoExceptions(IServiceProvider services, Type type)
        {
            try
            {
                return services.GetService(type);
            }
            catch
            {
                return null;
            }
        }
    }
}
﻿using System;

namespace nanoFramework.DependencyInjection
{
    /// <summary>
    /// The result of <see cref="CreateFactory()"/>.
    /// </summary>
    /// <param name="provider">The <see cref="IServiceProvider"/> to get service arguments from.</param>
    public delegate object ObjectFactory(IServiceProvider provider);
}
